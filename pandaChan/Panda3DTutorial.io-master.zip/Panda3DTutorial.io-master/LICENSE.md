The tutorial text and pages stored here are licensed under a Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0) License:
 https://creativecommons.org/licenses/by-nc/4.0/


Source code:

The source code to this game was written by Ian Eborn, and is licensed under the MIT license. See "codeLicense.txt" for the full text.


Sound effects:

"FemaleDmgNoise.ogg" excerpted from a recording by Sita Duncan, used with permission.

All other sound-files are copyright Ian Eborn, and licensed under a Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0) License:
 https://creativecommons.org/licenses/by-nc/4.0/


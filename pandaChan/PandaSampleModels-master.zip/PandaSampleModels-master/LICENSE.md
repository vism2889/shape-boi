All models, textures, and images included in this repository are copyright Ian Eborn, and licensed under a Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0) License:
 https://creativecommons.org/licenses/by-nc/4.0/

The samples in this directory are for (somewhat) advanced users.
Both Python and GLSL knowledge is probably needed.

There will be fewer explanations in comments about setting up common p3d stuff,
the code here will focus on specific problems and working solutions for them.

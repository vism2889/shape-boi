This repository contains sample models, as well as some UI assets. As long as you hold to the license (see "LICENSE.md"), feel free to use them!

You should find both Blender (.blend) and Panda3D egg (.egg) files for each model.

This is an attempt to create new and (hopefully better) samples for the Panda3D game engine.

Contributions are welcome.

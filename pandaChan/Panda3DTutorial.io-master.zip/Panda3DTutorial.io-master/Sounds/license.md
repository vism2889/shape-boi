"FemaleDmgNoise.ogg" excerpted from a recording by Sita Duncan, used with permission.

All other sound-files are copyright Ian Eborn, and licensed under a Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0) License:
 https://creativecommons.org/licenses/by-nc/4.0/
